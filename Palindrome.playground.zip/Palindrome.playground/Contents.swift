import Foundation

func isPalindrome(_ string: String) -> Bool {
    //nRemove whitespace and convert to lowercase for comparison.
    let lowercaseNoWhitespace = string.replacingOccurrences(of: " ", with: "").lowercased()
    
    // Chexk if string is equal to it's reversed string.
    return lowercaseNoWhitespace == String(lowercaseNoWhitespace.reversed())
}

// Example
let testString = "abccba"
if isPalindrome(testString) {
    print("\(testString) is a Palindrome!")
} else {
    print("\(testString) isn't a Palindrome!")
}

func findAllPalindromes(_ string: String) -> [String] {
    var palindromes = [String]()
    let length = string.count
    
    for i in 0..<length {
        for j in (i + 1)..<length {
            let startIndex = string.index(string.startIndex, offsetBy: i)
            let endIndex = string.index(string.startIndex, offsetBy: j)
            let substring = String(string[startIndex...endIndex])
            
            if isPalindrome(substring) {
                palindromes.append(substring)
            }
        }
    }
    return palindromes
}

// Example
let input = "abcbaracecar"
let palindromes = findAllPalindromes(input)
print("Palindromes in \(input):")
print(palindromes)
